#!/bin/bash
echo -e "run3(Ys).\n:quit" | dart run glp_repl.dart 2>&1 | head -20
