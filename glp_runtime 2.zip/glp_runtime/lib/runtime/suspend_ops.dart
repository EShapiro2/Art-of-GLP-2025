import 'machine_state.dart';
import 'suspend.dart';
import 'roq.dart';
import 'hanger.dart';

class SuspendOps {
  static Hanger suspendGoal({
    required GoalId goalId,
    required Pc kappa,
    required ROQueues roq,
    required Iterable<int> readers, // ReaderId values
  }) {
    print('[SuspendGoal] Suspending goal $goalId on readers: $readers');
    final h = Hanger(goalId: goalId, kappa: kappa, armed: true);
    for (final r in readers) {
      print('[SuspendGoal] Adding goal $goalId to ROQ for reader $r');
      roq.enqueue(r, SuspensionNote(r, h));
    }
    return h;
  }
}
