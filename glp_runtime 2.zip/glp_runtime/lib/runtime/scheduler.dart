import 'runtime.dart';
import '../bytecode/runner.dart';

class Scheduler {
  final GlpRuntime rt;
  final Map<Object?, BytecodeRunner> runners;

  Scheduler({required this.rt, BytecodeRunner? runner, Map<Object?, BytecodeRunner>? runners})
      : runners = runners ?? (runner != null ? {null: runner} : {});

  List<int> drain({int maxCycles = 1000}) {
    final ran = <int>[];
    var cycles = 0;
    while (rt.gq.length > 0 && cycles < maxCycles) {
      final act = rt.gq.dequeue();
      if (act == null) break;
      print('SCHEDULER: Dequeued goal ${act.id} at PC ${act.pc}');
      ran.add(act.id);
      final env = rt.getGoalEnv(act.id);
      final program = rt.getGoalProgram(act.id);
      print('SCHEDULER: Goal ${act.id} program=$program, available runners: ${runners.keys.toList()}');
      final runner = runners[program];
      if (runner == null) {
        print('SCHEDULER ERROR: No runner found for program $program for goal ${act.id}');
        throw StateError('No runner found for program $program for goal ${act.id}');
      }
      print('SCHEDULER: Running goal ${act.id} with runner for program $program');
      final cx = RunnerContext(rt: rt, goalId: act.id, kappa: act.pc, env: env);
      runner.run(cx);
      cycles++;
    }
    return ran;
  }
}
