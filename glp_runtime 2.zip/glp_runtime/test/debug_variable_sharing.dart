import 'package:glp_runtime/compiler/compiler.dart';

void main() {
  print('Testing variable sharing in clause/2 body structure');
  print('Source: clause(p1(X?), (r(Y?,X), q(Y))).');
  print('');

  final source = 'clause(p1(X?), (r(Y?,X), q(Y))).';
  final compiler = GlpCompiler();

  try {
    final result = compiler.compileWithMetadata(source);

    print('Compilation successful!');
    print('Variable map: ${result.variableMap}');
    print('');
    print('Bytecode:');
    for (int i = 0; i < result.program.ops.length; i++) {
      final op = result.program.ops[i];
      String details = '';

      // Extract varIndex for instructions that have it
      if (op.runtimeType.toString() == 'UnifyWriter' ||
          op.runtimeType.toString() == 'UnifyReader' ||
          op.runtimeType.toString() == 'GetVariable' ||
          op.runtimeType.toString() == 'SetWriter' ||
          op.runtimeType.toString() == 'SetReader') {
        try {
          final varIndex = (op as dynamic).varIndex;
          details = ' (varIndex=$varIndex)';
        } catch (e) {
          // Ignore if varIndex doesn't exist
        }
      }

      if (op.runtimeType.toString() == 'HeadStructure') {
        try {
          final functor = (op as dynamic).functor;
          final arity = (op as dynamic).arity;
          final argSlot = (op as dynamic).argSlot;
          details = ' ($functor/$arity, arg=$argSlot)';
        } catch (e) {}
      }

      print('  $i: ${op.runtimeType}$details');
    }
  } catch (e, stack) {
    print('Compilation failed: $e');
    print(stack);
  }
}
