import 'package:test/test.dart';

void main() {
  test('project skeleton exists', () {
    expect(true, isTrue);
  });
}
