/// Adapter skeleton: will bridge GLP's argument-indexed ops to Claude's VM.
/// No behavior yet — placeholder for wiring tests later.
class ClaudeEngineAdapter {
  const ClaudeEngineAdapter();
}
