import 'ast.dart';
import 'error.dart';

/// Variable information for semantic analysis
class VariableInfo {
  final String name;
  final bool isWriter;

  // Occurrence tracking
  int writerOccurrences = 0;
  int readerOccurrences = 0;

  // First occurrence location
  AstNode? firstOccurrence;

  // Register assignment (filled during analysis)
  int? registerIndex;

  // For readers: the paired writer name
  String? pairedWriter;

  // Variable classification
  bool isTemporary = false;  // X register (doesn't cross calls)
  bool isPermanent = false;  // Y register (survives across calls)

  VariableInfo(this.name, this.isWriter);

  bool get isSRSWValid {
    // Writer can occur once as writer
    if (isWriter && writerOccurrences > 1) return false;

    // Reader can occur once (unless ground guard allows multiple)
    // For now, simple check: reader occurs at most once
    // TODO: Allow multiple reader occurrences with ground guard
    if (!isWriter && readerOccurrences > 1) return false;

    return true;
  }

  @override
  String toString() => 'VariableInfo($name, writer×$writerOccurrences, reader×$readerOccurrences, reg=$registerIndex)';
}

/// Variable table for a single clause
class VariableTable {
  final Map<String, VariableInfo> _vars = {};

  // Track guard context
  bool _hasGroundGuard = false;
  final Set<String> _groundedVars = {};

  void recordWriterOccurrence(String name, AstNode node) {
    final info = _vars.putIfAbsent(name, () => VariableInfo(name, true));
    info.writerOccurrences++;
    info.firstOccurrence ??= node;
  }

  void recordReaderOccurrence(String name, AstNode node) {
    final writerName = name;  // Reader X? pairs with writer X

    // Ensure writer exists or create it
    final writerInfo = _vars.putIfAbsent(writerName, () => VariableInfo(writerName, true));

    // Record reader occurrence
    writerInfo.readerOccurrences++;
    writerInfo.firstOccurrence ??= node;
  }

  void markGrounded(String varName) {
    _groundedVars.add(varName);
  }

  bool isGrounded(String varName) => _groundedVars.contains(varName);

  void verifySRSW() {
    for (final info in _vars.values) {
      // Check writer occurrences
      if (info.writerOccurrences > 1) {
        throw CompileError(
          'SRSW violation: Writer variable "${info.name}" occurs ${info.writerOccurrences} times in clause',
          info.firstOccurrence?.line ?? 0,
          info.firstOccurrence?.column ?? 0,
          phase: 'analyzer'
        );
      }

      // Check reader occurrences (unless grounded)
      if (info.readerOccurrences > 1 && !isGrounded(info.name)) {
        throw CompileError(
          'SRSW violation: Reader variable "${info.name}?" occurs ${info.readerOccurrences} times without ground guard',
          info.firstOccurrence?.line ?? 0,
          info.firstOccurrence?.column ?? 0,
          phase: 'analyzer'
        );
      }
    }
  }

  List<VariableInfo> getAllVars() => _vars.values.toList();
  VariableInfo? getVar(String name) => _vars[name];
}

/// Annotated clause with variable table
class AnnotatedClause {
  final Clause ast;
  final VariableTable varTable;
  final bool hasGuards;
  final bool hasBody;

  AnnotatedClause(this.ast, this.varTable, 
      {this.hasGuards = false, this.hasBody = false});
}

/// Annotated procedure with entry point info
class AnnotatedProcedure {
  final Procedure ast;
  final String name;
  final int arity;
  final List<AnnotatedClause> clauses;
  int? entryPC;
  String? entryLabel;

  AnnotatedProcedure(this.ast, this.name, this.arity, this.clauses);

  String get signature => '$name/$arity';
}

/// Annotated program with semantic info
class AnnotatedProgram {
  final Program ast;
  final List<AnnotatedProcedure> procedures;
  
  // FIX: Add global variable tracking for user queries
  // When compiling queries like run((merge(...,X), merge(X?,...)))
  // we need to track that X is shared across the conjunction
  final Map<String, int> globalQueryVariables = {};

  AnnotatedProgram(this.ast, this.procedures);
}

/// Semantic analyzer
class Analyzer {
  // FIX: Add tracking for shared variables in queries
  final Map<String, int> _queryVarAllocation = {};
  int _nextQueryVarIndex = 0;
  
  AnnotatedProgram analyze(Program program) {
    final annotatedProcs = <AnnotatedProcedure>[];

    // FIX: Pre-scan for query variables if this is a user query
    // A user query typically compiles to a single procedure with no head arguments
    _prescanForQueryVariables(program);

    for (final proc in program.procedures) {
      annotatedProcs.add(_analyzeProcedure(proc));
    }

    final annotatedProgram = AnnotatedProgram(program, annotatedProcs);
    
    // FIX: Copy query variable allocations to the annotated program
    annotatedProgram.globalQueryVariables.addAll(_queryVarAllocation);
    
    return annotatedProgram;
  }
  
  // FIX: New method to pre-scan for shared variables in queries
  void _prescanForQueryVariables(Program program) {
    // Check if this looks like a user query (single procedure, likely with complex goal structure)
    if (program.procedures.isEmpty) return;
    
    // Look for procedures that appear to be queries (e.g., starting with run/1)
    for (final proc in program.procedures) {
      for (final clause in proc.clauses) {
        if (clause.body != null) {
          for (final goal in clause.body!) {
            _scanGoalForVariables(goal);
          }
        }
      }
    }
  }
  
  // FIX: Scan goals recursively for variables, especially in conjunctions
  void _scanGoalForVariables(Goal goal) {
    // Check if this is a conjunction run((A,B))
    if (goal.functor == 'run' && goal.args.length == 1) {
      final arg = goal.args[0];
      if (arg is StructTerm && arg.functor == ',' && arg.args.length == 2) {
        // This is a conjunction - scan both parts for shared variables
        _scanTermForVariables(arg.args[0]);
        _scanTermForVariables(arg.args[1]);
      } else {
        _scanTermForVariables(arg);
      }
    } else {
      // Regular goal - scan arguments
      for (final arg in goal.args) {
        _scanTermForVariables(arg);
      }
    }
  }
  
  // FIX: Recursively scan terms for variables
  void _scanTermForVariables(Term term) {
    if (term is VarTerm) {
      // Allocate a consistent index for this variable
      if (!_queryVarAllocation.containsKey(term.name)) {
        _queryVarAllocation[term.name] = _nextQueryVarIndex++;
      }
    } else if (term is StructTerm) {
      // Check for nested conjunction
      if (term.functor == ',' && term.args.length == 2) {
        // Conjunction - both parts share the same variable namespace
        _scanTermForVariables(term.args[0]);
        _scanTermForVariables(term.args[1]);
      } else {
        // Regular structure - scan arguments
        for (final arg in term.args) {
          _scanTermForVariables(arg);
        }
      }
    } else if (term is ListTerm) {
      if (term.head != null) {
        _scanTermForVariables(term.head!);
      }
      if (term.tail != null) {
        _scanTermForVariables(term.tail!);
      }
    }
  }

  AnnotatedProcedure _analyzeProcedure(Procedure proc) {
    final annotatedClauses = <AnnotatedClause>[];

    for (final clause in proc.clauses) {
      annotatedClauses.add(_analyzeClause(clause));
    }

    return AnnotatedProcedure(proc, proc.name, proc.arity, annotatedClauses);
  }

  AnnotatedClause _analyzeClause(Clause clause) {
    final varTable = VariableTable();

    // Analyze head
    _analyzeAtom(clause.head, varTable);

    // Analyze guards (if present)
    final hasGuards = clause.guards != null && clause.guards!.isNotEmpty;
    if (hasGuards) {
      for (final guard in clause.guards!) {
        _analyzeGuard(guard, varTable);
      }
    }

    // Analyze body (if present)
    final hasBody = clause.body != null && clause.body!.isNotEmpty;
    if (hasBody) {
      for (final goal in clause.body!) {
        _analyzeGoal(goal, varTable);
      }
    }

    // Verify SRSW constraint
    varTable.verifySRSW();

    // Assign register indices
    _assignRegisters(varTable);

    return AnnotatedClause(clause, varTable, hasGuards: hasGuards, hasBody: hasBody);
  }

  void _analyzeAtom(Atom atom, VariableTable varTable) {
    for (final arg in atom.args) {
      _analyzeTerm(arg, varTable);
    }
  }

  void _analyzeGoal(Goal goal, VariableTable varTable) {
    for (final arg in goal.args) {
      _analyzeTerm(arg, varTable);
    }
  }

  void _analyzeGuard(Guard guard, VariableTable varTable) {
    // Special handling for ground/1 and known/1
    if (guard.predicate == 'ground' && guard.args.length == 1) {
      final arg = guard.args[0];
      if (arg is VarTerm && arg.isReader) {
        // ground(X?) allows multiple reader occurrences
        varTable.markGrounded(arg.name);
      }
    }

    // Analyze guard arguments
    for (final arg in guard.args) {
      _analyzeTerm(arg, varTable);
    }
  }

  void _analyzeTerm(Term term, VariableTable varTable) {
    if (term is VarTerm) {
      if (term.isReader) {
        varTable.recordReaderOccurrence(term.name, term);
      } else {
        varTable.recordWriterOccurrence(term.name, term);
      }
    } else if (term is StructTerm) {
      for (final arg in term.args) {
        _analyzeTerm(arg, varTable);
      }
    } else if (term is ListTerm) {
      if (term.head != null) {
        _analyzeTerm(term.head!, varTable);
      }
      if (term.tail != null) {
        _analyzeTerm(term.tail!, varTable);
      }
    }
    // ConstTerm and UnderscoreTerm have no variables to track
  }

  void _assignRegisters(VariableTable varTable) {
    int nextIndex = 0;

    for (final info in varTable.getAllVars()) {
      // FIX: Check if this variable has a pre-allocated query index
      if (_queryVarAllocation.containsKey(info.name)) {
        info.registerIndex = _queryVarAllocation[info.name];
      } else {
        // For now, all variables are temporaries (X registers)
        // TODO: Analyze variable lifetimes to distinguish X vs Y registers
        info.isTemporary = true;
        info.registerIndex = nextIndex++;
      }
    }
  }
}
